<?php
include 'db.php';
$token = $_GET['token'];
$result = $conn->query("SELECT * FROM usuario WHERE token='$token' AND token_expira > NOW()");
if ($result->num_rows === 0) {
    die("Token inválido o expirado.");
}
?>
<form method="POST" action="guardar_nueva.php">
  <input type="hidden" name="token" value="<?php echo $token ?>">
  <label>Nueva contraseña:</label>
  <input type="password" name="nueva_contraseña" required>
  <button type="submit">Actualizar</button>
</form>

<?php
include 'db.php';
$token = $_POST['token'];
$nueva = password_hash($_POST['nueva_contraseña'], PASSWORD_DEFAULT);

$result = $conn->query("SELECT * FROM usuario WHERE token='$token' AND token_expira > NOW()");
if ($result->num_rows === 0) {
    die("Token inválido o expirado.");
}

$conn->query("UPDATE usuario SET contraseña='$nueva', token=NULL, token_expira=NULL WHERE token='$token'");
echo "Contraseña actualizada. Ya puedes iniciar sesión.";
?>

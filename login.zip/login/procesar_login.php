<?php
session_start();
include('conexion.php');  // Incluimos la conexión a la base de datos

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];

    // Consultar si el usuario existe en la base de datos
     // Consultar si el usuario existe y traer primer nombre y primer apellido
    $stmt = $conn->prepare("SELECT id, primer_nombre, primer_apellido, contraseña FROM usuario WHERE correo = ?");
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $primer_nombre, $primer_apellido, $contraseña_hash);



    if ($stmt->num_rows > 0) {
        $stmt->fetch();
    
        if (password_verify($contraseña, $contraseña_hash)) {
            // Guardar los datos del usuario en sesión
            $_SESSION['usuario_id'] = $id;
            $_SESSION['usuario_nombre'] = $primer_nombre . ' ' . $primer_apellido;
            $_SESSION['usuario_correo'] = $correo;  // 👈 guardar el nombre del usuario
    
            header("Location: ../index.php");  // 👈 redirigir al index
            exit();
        } else {
            echo "Contraseña incorrecta.";
        }
        
    } else {
        echo "No se encontró el usuario con ese correo.";
    }

    $stmt->close();
    $conn->close();
}
?>

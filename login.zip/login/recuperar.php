<!-- recuperar.php -->
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Recuperar contraseña</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    form { max-width: 400px; margin: auto; }
    input, button {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      font-size: 16px;
    }
  </style>
</head>
<body>
  <h2>Recuperar contraseña</h2>
  <form action="enviar_correo.php" method="POST">
    <label for="correo">Correo electrónico registrado:</label>
    <input type="email" name="correo" id="correo" required placeholder="Ej: usuario@correo.com">
    <button type="submit">Enviar enlace de recuperación</button>
  </form>
</body>
</html>

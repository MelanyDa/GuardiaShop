<?php
session_start(); // Iniciar sesión
include('conexion.php');  // Incluimos la conexión a la base de datos

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $primer_nombre = $_POST['primer_nombre'];
    $segundo_nombre = $_POST['segundo_nombre'];
    $primer_apellido = $_POST['primer_apellido'];
    $segundo_apellido = $_POST['segundo_apellido'];
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];
    $confirmar = $_POST['confirmar'];

    // Validar que la contraseña y la confirmación coincidan
    if ($contraseña !== $confirmar) {
        die("Las contraseñas no coinciden.");
    }

    // Verificar si el correo ya está registrado
    $stmt = $conn->prepare("SELECT id FROM usuario WHERE correo = ?");
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        die("Este correo electrónico ya está registrado.");
    }

    // Encriptar la contraseña
    $contraseña_hash = password_hash($contraseña, PASSWORD_DEFAULT);

    // Insertar los datos del usuario en la base de datos
    $stmt = $conn->prepare("INSERT INTO usuario (primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, correo, contraseña) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $primer_nombre, $segundo_nombre, $primer_apellido, $segundo_apellido, $correo, $contraseña_hash);


    if ($stmt->execute()) {
        // Obtener el ID insertado
        $usuario_id = $stmt->insert_id;

        // Crear sesión del usuario
        $_SESSION['usuario_id'] = $id;
        $_SESSION['usuario_nombre'] = $primer_nombre . ' ' . $primer_apellido; // ← igual que en index.php
        $_SESSION['usuario_correo'] = $correo;

        // Redireccionar al index
        header("Location: ../index.php");
        exit(); // Importante para evitar que siga ejecutando
    } else {
        echo "Error al registrar el usuario: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
<script>
  function toggleUserMenu() {
    const dropdown = document.getElementById('user-dropdown');
    dropdown.classList.toggle('hidden');
  }

  document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('user-dropdown');
    const toggle = document.querySelector('.menu-toggle');
    const menu = document.querySelector('.user-menu');

    if (!menu.contains(event.target)) {
      dropdown.classList.add('hidden');
    }
  });
</script>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $_POST['correo'];
    $result = $conn->query("SELECT * FROM usuario WHERE correo='$correo'");

    if ($result->num_rows > 0) {
        $token = bin2hex(random_bytes(32));
        $expira = date("Y-m-d H:i:s", strtotime('+1 hour'));
        $conn->query("UPDATE usuario SET token='$token', token_expira='$expira' WHERE correo='$correo'");

        // Configurar el correo
        $mail = new PHPMailer(true);
        try {
            // Configuración del servidor SMTP
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'morenoyurleolaya@gmail.com'; // tu correo real
            $mail->Password = 'uvrkdzpyvytocegr'; // contraseña de aplicaciónyvzvcjozygtqmmxq
            $mail->SMTPSecure = 'ssl'; // o tls
            $mail->Port = 465; // o 587


            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true,
                ],
            ];

            // Contenido del correo
            $mail->setFrom('morenoyurleolaya@gmail.com', 'GuardiaShop');
            $mail->addAddress($correo);
            $mail->isHTML(true);
            $mail->Subject = 'Recuperar tu contraseña';
            $link = "http://localhost/guardiashop/login/reset.php?token=$token";
            $mail->Body = "Haz clic <a href='$link'>aquí</a> para cambiar tu contraseña. Este enlace expira en 1 hora.";

            $mail->send();
            echo "✅ Se ha enviado un enlace a tu correo.";
        } catch (Exception $e) {
            echo "❌ Error al enviar el correo: " . $mail->ErrorInfo;
        }
    } else {
        echo "❌ Este correo no está registrado.";
    }
}
?>
